﻿using log4net.Util;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarBreaker.MyGraphics.Clouds
{
    public class CloundsSystem : IDisposable
    {
        ~CloundsSystem() //终结器
        {
            //使用终结器,手动释放CloundsTexture的资源
            CloundsTexture?.Dispose();
            CloundsTexture = null;
        }
        public void Dispose() => CloundsTexture.Dispose();
        public const int CLOUNDS_NUM = 50;
        public Clound[] clounds = null;
        public Asset<Texture2D> CloundsTexture = null;
        public int NewCloundTime = 0;
        public int OldCloundTime = 0;
        public void Draw()
        {
            SpriteBatch sb = Main.spriteBatch;
            if (clounds == null || clounds.Length != CLOUNDS_NUM)
            {
                clounds = new Clound[CLOUNDS_NUM];
                bool flag = Main.windSpeedCurrent > 0f;
                for (int i = 0; i < clounds.Length; i++)
                {
                    Vector2 pos = new Vector2(Main.screenWidth / (float)CLOUNDS_NUM * i, Main.screenHeight - 300 + Main.rand.Next(100, 300));
                    NewClound(pos, flag.ToDirectionInt() * Vector2.UnitX * Main.rand.NextFloat() * 2, Main.rand.NextFloat(1.5f, 3f));
                }
                OldCloundTime = 50;
            }
            CloundsTexture ??= ModContent.Request<Texture2D>((GetType().Namespace + ".Clounds").Replace('.', '/'));
            sb.End();
            sb.Begin(SpriteSortMode.Deferred, BlendState.Additive, SamplerState.PointWrap, DepthStencilState.None, RasterizerState.CullNone,
                null,Main.GameViewMatrix.TransformationMatrix);
            NewCloundTime++;
            if(NewCloundTime > OldCloundTime)
            {
                NewCloundTime = 0;
                OldCloundTime = Main.rand.Next(40,60);
                bool flag = Main.windSpeedCurrent > 0f;
                Vector2 pos = new Vector2(flag ? -100 : Main.screenWidth + 100, Main.screenHeight - 300 + Main.rand.Next(100, 300));
                NewClound(pos, flag.ToDirectionInt() * Vector2.UnitX * Main.rand.NextFloat() * 2, Main.rand.NextFloat(1.5f, 3f));
            }
            for(int i =0;i<CLOUNDS_NUM;i++)
            {
                clounds[i].Draw(CloundsTexture.Value, sb);
                clounds[i].Pos += clounds[i].Vel;
                clounds[i].Pos.X += Main.windSpeedCurrent * 5;
            }
            sb.End();
            sb.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, Main.DefaultSamplerState, DepthStencilState.None, Main.Rasterizer, null, Main.Transform);
        }
        public void NewClound(Vector2 pos, Vector2 vel, float scale)
        {
            int i;
            for (i = 0; i < clounds.Length; i++)
            {
                if (!clounds[i].Active) break;
            }
            if (i >= 50)
            {
                return;
            }
            Clound clound = new(pos, vel, scale,Main.rand.Next(4) + 1)
            {
                whoAmI = i
            };
            clounds[i] = clound;
        }
    }
}
