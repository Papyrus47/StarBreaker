﻿namespace StarBreaker.MyGraphics.Clouds
{
    public struct Clound
    {
        public bool Active;
        public Vector2 Pos;
        public Vector2 Vel;
        public float scale;
        public int whoAmI;
        public int frame;
        public float Rot;
        public Clound(Vector2 pos,Vector2 vel,float scale,int frame)
        {
            Pos = pos;
            Vel = vel;
            this.scale = scale;
            Active = true;
            whoAmI = 0;
            this.frame = frame;
            Rot = Main.rand.NextFloat(6.28f);
        }
        public void Draw(Texture2D tex,SpriteBatch sb)
        {
            int y = tex.Height / 2 * (frame % 2);
            if (frame <= 2) y = 0;
            const float rgb = 0.35f;
            Rectangle rectangle = new(tex.Width / 2 * (frame % 2), y,tex.Width / 2, tex.Height / 2);
            Color color = new Color(rgb, rgb, rgb, 0.35f * MathF.Sqrt(scale));
            sb.Draw(tex, Pos, rectangle,color, Rot, rectangle.Size() * 0.5f, scale, SpriteEffects.None, 0f);
            if(Pos.X > Main.screenWidth + 100 || Pos.X < -100)
            {
                Active = false;
            }
        }
        public bool HasClound => this != default;
        public static bool operator ==(Clound clound1, Clound clound2) => clound1.scale == clound2.scale && clound1.Pos == clound2.Pos && clound2.Vel == clound1.Vel;
        public static bool operator !=(Clound clound1, Clound clound2) => clound1.scale != clound2.scale || clound1.Pos != clound2.Pos || clound2.Vel != clound1.Vel;

        public override bool Equals(object obj)
        {
            if(obj is Clound clound)
            {
                return this == clound;
            }
            return false;
        }

        public override int GetHashCode() => whoAmI;
    }
}
